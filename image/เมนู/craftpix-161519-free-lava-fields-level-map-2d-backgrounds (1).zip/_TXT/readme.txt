Dimbo
http://www.dafont.com/dimbo.font